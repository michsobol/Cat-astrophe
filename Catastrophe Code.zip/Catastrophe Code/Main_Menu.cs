using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Main_Menu : MonoBehaviour
{
    //variables set up 
    public string nextScene;
    public string controlScene;
    public string creditsScene;

    //methods for all of the buttons on the main menu
    public void Start_Button(){
        SceneManager.LoadScene(nextScene);
        if(FindObjectsOfType(typeof(Music)).Length > 0){
            Destroy(Music.musicObject);
            return;
        }
    }

    public void Exit_Button(){
        Application.Quit();
    }

    public void Credits_Button(){
        SceneManager.LoadScene(creditsScene);
    }

    public void Controls_Button(){
        SceneManager.LoadScene(controlScene);
    }
}
