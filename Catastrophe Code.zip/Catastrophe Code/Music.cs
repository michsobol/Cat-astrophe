using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Music : MonoBehaviour
{
     private AudioSource musicPlayer;
     public static GameObject musicObject;
     static Music instance = null;

     private void Awake(){
        musicObject = GameObject.FindWithTag("Music");
        musicPlayer = musicObject.GetComponent<AudioSource>();
        if (instance != null){
         Destroy (gameObject);
        }else {
            instance = this;
            GameObject.DontDestroyOnLoad(gameObject);
        }
     }
 
 }
