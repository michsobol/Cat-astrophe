using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Paw : MonoBehaviour
{
    //variables set up 
    public Texture[] pawprints = new Texture[6]; //Array holding different pawprint images
    public RawImage pawPrintImage;
    private int selected = 0;

    void Start(){
        updatePaw();
        pawPrintImage.texture = pawprints[selected];
    }

    //checks how high the score is and displays the appropriate pawprint
    //pawprints are like stars, so a full pawprint is 5 stars and one with 2 filled in is 2 stars
    void updatePaw(){
        if(Score.scoreNumber >= 400){
            selected = 5;
        }else if (400 > Score.scoreNumber && Score.scoreNumber >= 300){
            selected = 4;  
        }else if (300 > Score.scoreNumber && Score.scoreNumber >= 240){
            selected = 3;  
        }else if (240 > Score.scoreNumber && Score.scoreNumber >= 120){
            selected = 2;  
        }else if (120 > Score.scoreNumber && Score.scoreNumber >= 60){
            selected = 1;  
        }else{
            selected = 0;
        }
    }
}
