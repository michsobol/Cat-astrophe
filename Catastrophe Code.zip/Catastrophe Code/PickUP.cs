using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickUP : MonoBehaviour
{
    //variables set up 
    private Rigidbody object_rigidbody;
    private float speedObject;

    void Start(){
        object_rigidbody = GetComponent<Rigidbody>();
    }

    void Update(){
        speedObject = object_rigidbody.velocity.magnitude; 
    }
    
    //when the speed is high enough and the object collided with a "nonpickable" object, then the object is destroyed and the score increases
    //when the speed is high enough and the object collided with a "pickable" object, then both the objects are destroyed and the score increases
    private void OnCollisionEnter(Collision collisionInfo){
        if(speedObject > 4){
            if(collisionInfo.gameObject.tag == "Nonpickable"){
                Destroy(gameObject);
                Debug.Log("--------");
                Debug.Log(speedObject);
                Score.scoreNumber += 20;
            } else if(collisionInfo.gameObject.tag == "Pickable"){
                Destroy(gameObject);
                Destroy(collisionInfo.gameObject);
                Debug.Log("woah!!");
                Debug.Log(speedObject);
                Score.scoreNumber += 60;
            }
        }
   }

}
