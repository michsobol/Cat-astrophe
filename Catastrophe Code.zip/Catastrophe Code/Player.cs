using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

		//variables set up 
		private Animator anim;
		private CharacterController controller;

		public float speed = 1.2f;
		public float turnSpeed = 1.4f;
		public float jumpSpeed = 1.2f;
		public float ySpeed;
		public float magnitude;
		private Vector3 moveDirection = new Vector3(0, 0, 0);
		private Vector3 velocity;
		public float gravity;
		private bool isJumping = false;
		private bool isGrounded = true;
		private bool pickingUp = false;
		private bool throwable = false;
		public Transform pickUpSpot;
		public GameObject objectToPick;


		void Start () {
			controller = GetComponent <CharacterController>();
			anim = gameObject.GetComponentInChildren<Animator>();
		}

		void Update () {

			Animation(); //calls animation method

			//movement code
			moveDirection = transform.forward * Input.GetAxis("Vertical") * speed;

			float turn = Input.GetAxis("Horizontal");
			transform.Rotate(0, turn * turnSpeed * Time.deltaTime, 0);
			//end of movement code

			//Jump Code
			ySpeed += Physics.gravity.y * Time.deltaTime;

			//animations for jumping
			if(controller.isGrounded){
				ySpeed = -1f;
				anim.SetBool("IsGrounded", true);
				isGrounded = true;
				anim.SetBool("IsJumping", false);
				isJumping = false;
				anim.SetBool("IsFalling", false);
				if(Input.GetKey (KeyCode.Space)){
					ySpeed = jumpSpeed;
					anim.SetBool("IsJumping", true);
					isJumping = true;
					moveDirection.y += ySpeed * Time.deltaTime;
				}
			} else{
				anim.SetBool("IsGrounded", false);
				isGrounded = false;

				if((isJumping && ySpeed < 0) || ySpeed < -2){
					anim.SetBool("IsFalling", true);
				}

			}

			magnitude = Mathf.Clamp01(moveDirection.magnitude) * speed;
			velocity = moveDirection * magnitude;
			velocity.y = ySpeed;
			controller.Move(velocity * Time.deltaTime);

			//End of Jump Code

			//start of picking up function code
			if(pickingUp == true){
				if(Input.GetKey ("m")){
					objectToPick.GetComponent<MeshCollider>().enabled = false;
					objectToPick.GetComponent<Rigidbody>().useGravity = false;
					objectToPick.transform.position = pickUpSpot.position;
					objectToPick.transform.parent = GameObject.Find("PickUpSpot").transform;
					objectToPick.GetComponent<Rigidbody>().freezeRotation = true;
					throwable = true;
				}else{
					objectToPick.gameObject.GetComponent<MeshCollider>().enabled = true;
					objectToPick.gameObject.transform.parent = null;
					objectToPick.gameObject.GetComponent<Rigidbody>().useGravity = true;
					objectToPick.gameObject.GetComponent<Rigidbody>().freezeRotation = false;
					throwable = false;
					pickingUp = false;
				}
	
			}
			//end of picking up function code
		}

		//method that controls what animations play for standard movment 
		void Animation (){
			
			if (Input.GetKey ("w") || Input.GetKey ("s")) {
				if (Input.GetKey (KeyCode.LeftShift) && controller.isGrounded){
					anim.SetInteger ("AnimationPar", 2);
					speed = 2.0f;
				}
				else{
					anim.SetInteger ("AnimationPar", 1);
					speed = 1.2f;
				} 
			}else {
				anim.SetInteger ("AnimationPar", 0);
				speed = 1.2f;
			}
		}

		//checks for if the player collides with a destroyable object
		//top part is for when the player collides with a destroyable object while holding shift
		//bottom part is for activating picking up code

		private void OnCollisionEnter(Collision collisionInfo){
			if(Input.GetKey (KeyCode.LeftShift) && !Input.GetKey ("m")){
				Destroy(collisionInfo.gameObject);
				Debug.Log("bing bing");
				Score.scoreNumber += 10;
			}
			if(pickingUp == false){
				if(collisionInfo.gameObject.tag == "Pickable"){
					if(Input.GetKey ("m") && !Input.GetKey (KeyCode.LeftShift)){
						pickingUp = true;
						objectToPick = collisionInfo.gameObject;
					} 
				}
			}
	}

	
}
