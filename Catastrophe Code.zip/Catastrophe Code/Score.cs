using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Score : MonoBehaviour
{
    //variables set up 
    public static int scoreNumber = 0;
    public TextMeshProUGUI scoreText;
    public static bool restart = false;

    void Start()
    {
        scoreText.GetComponent<TextMeshProUGUI>();
        scoreText.text = "Score: " + scoreNumber;
    }

    //score update
    //restart is set to true only when next level button is pressed
    void Update(){
        scoreText.text = "Score: " + scoreNumber;
        if(restart == true){
            scoreNumber = 0;
            restart = false;
        }
    }
}
