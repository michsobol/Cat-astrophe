using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class Timer : MonoBehaviour
{
    //variables set up 
    public float timerDuration = 60.0f;
    public TextMeshProUGUI timerText;
    public GameObject pausedText;
    public string nextScene;
    public bool isPaused = false;
    private int pauseTracker = 0;

    // Start is called before the first frame update
    void Start()
    {
        pausedText.SetActive(false);
        timerText.GetComponent<TextMeshProUGUI>();
        conversions(timerDuration,timerText);
    }

    // Update is called once per frame
    // decreases time until the end, where it will move to the end of level scene
    // includes code for pausing the game when player presses esc
    void Update()
    {
        if(timerDuration > 1){
            timerDuration -= Time.deltaTime;
            conversions(timerDuration,timerText); 
        } else{
            timerDuration = 0;
            SceneManager.LoadScene(nextScene);
        }

        if(Input.GetKeyDown(KeyCode.Escape)){
            if(pauseTracker == 0){
                PauseGame();
            } else if(pauseTracker == 1){
                ResumeGame();
            }
        }

    }
    
    //all of the math conversions to have the time in seconds to display in minutes and seconds
    private void conversions(float timerDuration, TextMeshProUGUI timerText){
        float minutes = Mathf.FloorToInt(timerDuration / 60);
        float seconds = Mathf.FloorToInt(timerDuration % 60);
        //Debug.Log(timerDuration);
        timerText.text = string.Format("{0:00}:{1:00}",minutes,seconds);
    }

    //paused game method
    void PauseGame(){
        Time.timeScale = 0;
        pauseTracker += 1;
        pausedText.SetActive(true);
        isPaused = !isPaused;
    }
    
    //resumed game method
    void ResumeGame(){
        Time.timeScale = 1;
        pauseTracker = 0;
        pausedText.SetActive(false);
        isPaused = !isPaused;
    }
}
